# -*- coding: utf-8 -*-
from myHeader import *
import pygame, sys
from pygame.locals import *     # ���̰��� ��� ����ϱ� ����

## functions
def initProcess():
    initMap()

    return

def inputProcess():
    checkForQuit()

    if pygame.key.get_pressed()[pygame.K_DOWN] != 0:
        print("down")
        m_fallingTetris['y'] += 1
        moveDown = True
    elif pygame.key.get_pressed()[pygame.K_LEFT] != 0:
        print("left")
        m_fallingTetris['x'] -= 1
        moveLeft = True
    elif pygame.key.get_pressed()[pygame.K_RIGHT] != 0:
        print("right")
        m_fallingTetris['x'] += 1
        moveRight = True
    elif pygame.key.get_pressed()[pygame.K_UP] != 0:
        print("up")
        m_fallingTetris['rotation'] += 1
        keyUp = True

    return

def dataProcess():
    global m_GameStep
    global m_fallingTetris
    time.sleep(0.3)
    if m_GameStep == STEP.ready.value:
        m_fallingTetris = newTetris()
        m_newTetris = newTetris()
        m_GameStep = STEP.input.value
    elif m_GameStep == STEP.input.value:
        if isBlocked():
            setOnMap()
            m_GameStep = STEP.check_erase.value
            # m_fallingTetris['y'] += BOXSIZE
        else:
            m_fallingTetris['y'] += 1
    elif m_GameStep == STEP.check_erase.value:
        m_GameStep = STEP.erase.value
        
    elif m_GameStep == STEP.erase.value:
        m_GameStep = STEP.gameover.value
        
    elif m_GameStep == STEP.gameover.value:
        m_GameStep = STEP.ready.value

    return

def renderProcess():
    DISPLAYSURF.fill(BLACK)
    drawBoard()
    drawMovingTetris()

    pygame.display.update()
    FPSCLOCK.tick(FPS)
    return

def releaseProcess():
    return

g_time = time.time()
def mainLoop():
    global g_time
    curTime = time.time()
    if curTime - g_time >= 0.1:
        inputProcess()
    if curTime - g_time >= 0.5:
        dataProcess()
        g_time = time.time()
    renderProcess()

# init
def initMap():
    for i in range(BOARD_HEIGHT_CNT):
        m_Map.append([BLANK]*BOARD_WIDTH_CNT)
# input

# data
def newTetris():
    shape = random.choice(list(PIECES.keys()))
    newBox = {'shape': shape,
                'rotation': random.randint(0, len(PIECES[shape]) - 1),
                'x': int(BOARD_WIDTH_CNT / 2),
                'y': -2, # start it above the board (i.e. less than 0)
                'color': random.randint(0, len(COLORS)-1)}
    return newBox

def isBlocked():
    for x in range(TETRIS_WIDTH_CNT):
        for y in range(TETRIS_HEIGHT_CNT):
            if PIECES[m_fallingTetris['shape']][m_fallingTetris['rotation']][y][x] != BLANK:
                # �� ������ blank�� �ƴϸ�
                # �ʿ����� ��ǥ�� �����´�.
                map_X = m_fallingTetris['x']
                map_Y = m_fallingTetris['y']
                map_X += x
                map_Y += y
                if map_Y+1 >= BOARD_HEIGHT_CNT: # ���� �ٴ��̸�
                    return True
                if m_Map[map_Y+1][map_X] != BLANK:    # �̹� ���� ������ ������
                    return True
    return False

def setOnMap():
    for x in range(TETRIS_WIDTH_CNT):
        for y in range(TETRIS_HEIGHT_CNT):
            if PIECES[m_fallingTetris['shape']][m_fallingTetris['rotation']][y][x] != BLANK:
                map_X = m_fallingTetris['x']
                map_Y = m_fallingTetris['y']
                map_X += x
                map_Y += y
                m_Map[map_Y][map_X] = m_fallingTetris['color']
# render
def drawBoard():
    # �׵θ� �׸���
    pygame.draw.rect(DISPLAYSURF, BORDERCOLOR, (TETRIS_LEFT_GAP, TETRIS_TOP_GAP, (BOARD_WIDTH_CNT * BOXSIZE) + 8, (BOARD_HEIGHT_CNT * BOXSIZE) + 8), 5)
    # �� �׸���
    for y in range(BOARD_HEIGHT_CNT):
        for x in range(BOARD_WIDTH_CNT):
            drawBox(y, x, m_Map[y][x])
def drawBox(y,x,color):
    if color==BLANK:
        return
    pygame.draw.rect(DISPLAYSURF,COLORS[color],(TETRIS_LEFT_GAP+x*BOXSIZE+6,TETRIS_TOP_GAP+y*BOXSIZE+5,BOXSIZE-1,BOXSIZE-1))

def drawMovingTetris():
    for x in range(TETRIS_WIDTH_CNT):
        for y in range(TETRIS_HEIGHT_CNT):
            if PIECES[m_fallingTetris['shape']][m_fallingTetris['rotation']][y][x] != BLANK:
                map_X = m_fallingTetris['x']
                map_Y = m_fallingTetris['y']
                map_X += x
                map_Y += y
                drawBox(map_Y,map_X,m_fallingTetris['color'])
# release

def terminate():
    pygame.quit()
    sys.exit()

def checkForQuit():
    for event in pygame.event.get(QUIT): # get all the QUIT events
        terminate() # terminate if any QUIT events are present
    for event in pygame.event.get(KEYUP): # get all the KEYUP events
        if event.key == K_ESCAPE:
            terminate() # terminate if the KEYUP event was for the Esc key
        pygame.event.post(event) # put the other KEYUP event objects back

def checkForKeyPress():
    checkForQuit()

    for event in pygame.event.get([KEYDOWN, KEYUP]):
        if event.type == KEYDOWN:
            continue
        return event.key
    return None

#### main
def main():
    global FPSCLOCK, DISPLAYSURF, BASICFONT, BIGFONT
    pygame.init()
    FPSCLOCK = pygame.time.Clock()
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH,WINDOWHEIGHT))
    pygame.display.set_caption('EDGE')
    # showTextScreen('EDGE')
    # pygame.draw.rect(DISPLAYSURF, BORDERCOLOR, (TETRIS_LEFT_GAP, TETRIS_TOP_GAP, (TETRIS_LEFT_GAP * BOXSIZE) + 8, (BOARD_HEIGHT_CNT * BOXSIZE) + 8), 5)

    #while checkForKeyPress() == None:
    #    pygame.display.update()
    #    FPSCLOCK.tick()


    # start game
    initProcess()
    while True:
        mainLoop()

    releaseProcess()






## function calls
main()
